//! ffprobe logic
use crate::command::args::PixelFormat;
use crate::process::{Item, child};
use anyhow::{Context, anyhow};
use std::{
    fmt,
    path::{Path, PathBuf},
    sync::Arc,
    time::Duration,
};
use tokio::process::Command;
use tokio_stream::StreamExt;

pub const PROBE_TIMEOUT: Duration = Duration::from_secs(30);
const JSON_LIMIT: usize = 1024 * 1024;
const DIAGNOSTIC_LIMIT: usize = 4 * 1024;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ProbeFailureKind {
    Unavailable,
    TimedOut,
    Rejected { code: Option<i32> },
    InvalidOutput,
    Supervision,
}

#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ProbeDiagnostic {
    pub text: String,
    pub truncated: bool,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProbeFailure {
    pub input: PathBuf,
    pub kind: ProbeFailureKind,
    pub detail: String,
    pub diagnostic: ProbeDiagnostic,
    pub cleanup_failures: Vec<String>,
}

impl fmt::Display for ProbeFailure {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "ffprobe: {}", self.detail)?;
        if !self.diagnostic.text.is_empty() {
            write!(f, "; stderr: {}", self.diagnostic.text)?;
        }
        if self.diagnostic.truncated {
            write!(f, " [diagnostic tail truncated]")?;
        }
        for failure in &self.cleanup_failures {
            write!(f, "; cleanup failed: {failure}")?;
        }
        Ok(())
    }
}

impl std::error::Error for ProbeFailure {}

#[derive(Default)]
struct DiagnosticTail {
    input: PathBuf,
    pending: Vec<u8>,
    bytes: Vec<u8>,
    truncated: bool,
}

impl DiagnosticTail {
    fn push(&mut self, chunk: &[u8]) {
        #[cfg(unix)]
        let path = {
            use std::os::unix::ffi::OsStrExt;
            self.input.as_os_str().as_bytes()
        };
        #[cfg(not(unix))]
        let rendered = self.input.to_string_lossy();
        #[cfg(not(unix))]
        let path = rendered.as_bytes();
        if path.is_empty() {
            self.append(chunk);
            return;
        }
        self.pending.extend_from_slice(chunk);
        let mut safe = Vec::new();
        while let Some(start) = self
            .pending
            .windows(path.len())
            .position(|part| part == path)
        {
            safe.extend_from_slice(&self.pending[..start]);
            safe.extend_from_slice(b"<probe-input>");
            self.pending.drain(..start + path.len());
        }
        // Keep a possible path prefix across read boundaries, before the tail cap.
        let held = (1..path.len().min(self.pending.len() + 1))
            .rev()
            .find(|length| self.pending.ends_with(&path[..*length]))
            .unwrap_or(0);
        safe.extend(self.pending.drain(..self.pending.len() - held));
        self.append(&safe);
    }

    fn append(&mut self, chunk: &[u8]) {
        let overflow = (self.bytes.len() + chunk.len()).saturating_sub(DIAGNOSTIC_LIMIT);
        if overflow > 0 {
            self.truncated = true;
            let remove = overflow.min(self.bytes.len());
            self.bytes.drain(..remove);
        }
        self.bytes
            .extend_from_slice(&chunk[chunk.len().saturating_sub(DIAGNOSTIC_LIMIT)..]);
    }

    fn failure(&self, kind: ProbeFailureKind, detail: impl Into<String>) -> ProbeFailure {
        let mut bytes = self.bytes.clone();
        // A truncated write may stop partway through a path; never expose that prefix.
        if !self.pending.is_empty() {
            bytes.extend_from_slice(b"<probe-input>");
        }
        let text = String::from_utf8_lossy(&bytes);
        let mut start = text.len().saturating_sub(DIAGNOSTIC_LIMIT);
        while !text.is_char_boundary(start) {
            start += 1;
        }
        ProbeFailure {
            input: self.input.clone(),
            kind,
            detail: detail.into(),
            diagnostic: ProbeDiagnostic {
                text: text[start..].to_owned(),
                truncated: self.truncated || start > 0,
            },
            cleanup_failures: Vec::new(),
        }
    }
}

pub struct Ffprobe {
    /// Duration of video.
    pub duration: Result<Duration, ProbeError>,
    /// The video has audio stream(s).
    pub has_audio: bool,
    /// Audio number of channels (if multiple channel the highest).
    pub max_audio_channels: Option<i64>,
    /// Video frame rate.
    pub fps: Result<f64, ProbeError>,
    pub resolution: Option<(u32, u32)>,
    pub is_image: bool,
    pub pix_fmt: Option<String>,
}

impl Ffprobe {
    pub fn pixel_format(&self) -> Option<PixelFormat> {
        let pf = self.pix_fmt.as_deref()?;
        PixelFormat::try_from(pf).ok()
    }

    pub fn nframes(&self) -> Result<u64, ProbeError> {
        match (&self.fps, &self.duration) {
            (Ok(fps), Ok(duration)) => {
                let frames = (fps * duration.as_secs_f64()).round();
                if frames.is_normal() && frames.is_sign_positive() {
                    Ok(frames as _)
                } else {
                    Err(ProbeError(format!("Invalid nframes {frames}")))
                }
            }
            (Err(e), _) | (_, Err(e)) => Err(e.clone()),
        }
    }
}

/// Probe through the same contained, registered child path as FFmpeg.
/// Dropping the future leaves the child registered for `cancel_job` settlement.
pub async fn probe(input: &Path) -> Result<Ffprobe, ProbeFailure> {
    let timeout = PROBE_TIMEOUT;
    let mut command = Command::new(crate::tools::ffprobe());
    command.args([
        "-v",
        "error",
        "-show_format",
        "-show_streams",
        "-of",
        "json",
    ]);
    command.arg("-i").arg(input);
    let mut diagnostic = DiagnosticTail {
        input: input.to_owned(),
        ..DiagnosticTail::default()
    };
    let mut stream = child::spawn(command)
        .map_err(|error| diagnostic.failure(ProbeFailureKind::Unavailable, error.to_string()))?;
    let deadline = tokio::time::sleep(timeout);
    tokio::pin!(deadline);
    let mut stdout = Vec::new();
    let captured = loop {
        tokio::select! {
            biased;
            _ = &mut deadline => break Err(diagnostic.failure(
                ProbeFailureKind::TimedOut, format!("timed out after {} seconds", timeout.as_secs_f64()),
            )),
            item = stream.next() => match item {
                Some(Item::Stdout(chunk)) => {
                    if stdout.len().saturating_add(chunk.len()) > JSON_LIMIT {
                        break Err(diagnostic.failure(ProbeFailureKind::InvalidOutput, "JSON exceeded the capture limit"));
                    }
                    stdout.extend(chunk);
                }
                Some(Item::Stderr(chunk)) => diagnostic.push(&chunk),
                Some(Item::Done(Ok(status))) if status.success() => break Ok(()),
                Some(Item::Done(Ok(status))) => break Err(diagnostic.failure(
                    ProbeFailureKind::Rejected { code: status.code() }, "rejected the media",
                )),
                Some(Item::Done(Err(error))) => break Err(diagnostic.failure(
                    ProbeFailureKind::Supervision, error.to_string(),
                )),
                None => break Err(diagnostic.failure(ProbeFailureKind::Supervision, "child ended without an exit status")),
            },
        }
    };
    let handle = Arc::clone(stream.child());
    // The stream can hold the child's mutex while waiting after pipe EOF.
    // Release it before failure settlement takes the same mutex.
    drop(stream);
    let cleanup_failures = child::terminate(&handle).await;
    if let Err(mut failure) = captured {
        failure.cleanup_failures = cleanup_failures;
        return Err(failure);
    }
    if !cleanup_failures.is_empty() {
        let mut failure =
            diagnostic.failure(ProbeFailureKind::Supervision, "process settlement failed");
        failure.cleanup_failures = cleanup_failures;
        return Err(failure);
    }
    let probe: ffprobe::FfProbe = serde_json::from_slice(&stdout)
        .map_err(|error| diagnostic.failure(ProbeFailureKind::InvalidOutput, error.to_string()))?;

    let is_image = image_format(&probe.format.format_name);
    let fps = read_fps(&probe);
    let duration = read_duration(&probe);
    let has_audio = probe
        .streams
        .iter()
        .any(|s| s.codec_type.as_deref() == Some("audio"));
    let max_audio_channels = probe
        .streams
        .iter()
        .filter(|s| s.codec_type.as_deref() == Some("audio"))
        .filter_map(|a| a.channels)
        .max();

    let resolution = probe
        .streams
        .iter()
        .filter(|s| s.codec_type.as_deref() == Some("video"))
        .find_map(|s| {
            let w = s.width.and_then(|w| u32::try_from(w).ok())?;
            let h = s.height.and_then(|w| u32::try_from(w).ok())?;
            Some((w, h))
        });

    let pix_fmt = probe
        .streams
        .into_iter()
        .filter(|s| s.codec_type.as_deref() == Some("video"))
        .find_map(|s| s.pix_fmt);

    Ok(Ffprobe {
        duration: duration.map_err(ProbeError::from),
        fps: fps.map_err(ProbeError::from),
        has_audio,
        max_audio_channels,
        resolution,
        is_image,
        pix_fmt,
    })
}

fn image_format(format: &str) -> bool {
    format.split(',').any(|name| {
        matches!(name, "image2" | "image2pipe" | "gif" | "apng" | "ico") || name.ends_with("_pipe")
    })
}

fn read_duration(probe: &ffprobe::FfProbe) -> anyhow::Result<Duration> {
    match probe.format.duration.as_deref() {
        Some(duration_s) => {
            let duration_f = duration_s
                .parse::<f64>()
                .with_context(|| format!("invalid ffprobe video duration: {duration_s:?}"))?;
            Duration::try_from_secs_f64(duration_f)
                .map_err(|e| anyhow!("{e}: ffprobe video duration: {duration_s:?}"))
        }
        None => Ok(Duration::ZERO),
    }
}

fn read_fps(probe: &ffprobe::FfProbe) -> anyhow::Result<f64> {
    let vstream = probe
        .streams
        .iter()
        .find(|s| s.codec_type.as_deref() == Some("video"))
        .context("no video stream found")?;

    parse_frame_rate(&vstream.avg_frame_rate)
        .or_else(|| parse_frame_rate(&vstream.r_frame_rate))
        .context("invalid ffprobe video frame rate")
}

/// parse "x/y" or float strings.
pub fn parse_frame_rate(rate: &str) -> Option<f64> {
    if let Some((x, y)) = rate.split_once('/') {
        let x: f64 = x.parse().ok()?;
        let y: f64 = y.parse().ok()?;
        if x <= 0.0 || y <= 0.0 {
            return None;
        }
        Some(x / y)
    } else {
        rate.parse()
            .ok()
            .filter(|f: &f64| f.is_finite() && *f > 0.0)
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProbeError(String);

impl fmt::Display for ProbeError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

impl From<anyhow::Error> for ProbeError {
    fn from(err: anyhow::Error) -> Self {
        Self(format!("{err}"))
    }
}

impl std::error::Error for ProbeError {}

#[cfg(test)]
mod tests {
    use super::{DIAGNOSTIC_LIMIT, DiagnosticTail, ProbeFailureKind, image_format};

    #[test]
    fn image_classification_uses_demuxer_evidence() {
        for format in [
            "image2",
            "image2pipe",
            "png_pipe",
            "jpeg_pipe",
            "webp_pipe",
            "gif",
            "apng",
            "ico",
        ] {
            assert!(image_format(format));
        }
        for format in ["mov,mp4,m4a,3gp,3g2,mj2", "matroska,webm", "avi", "mpegts"] {
            assert!(!image_format(format));
        }
    }

    #[test]
    fn paths_are_scrubbed_across_chunks_before_the_tail_boundary() {
        let path = "/fixture/private/sample.crf.mkv";
        let mut tail = DiagnosticTail {
            input: path.into(),
            ..DiagnosticTail::default()
        };
        for byte in format!("error {path}").bytes() {
            tail.push(&[byte]);
        }
        tail.push(&vec![b'x'; DIAGNOSTIC_LIMIT - path.len() / 2]);
        let failure = tail.failure(ProbeFailureKind::Rejected { code: Some(1) }, "rejected");
        assert!(!failure.diagnostic.text.contains("private"));
        assert!(!failure.diagnostic.text.contains("sample.crf.mkv"));
        assert!(failure.diagnostic.text.len() <= DIAGNOSTIC_LIMIT);
        let mut partial = DiagnosticTail {
            input: path.into(),
            ..DiagnosticTail::default()
        };
        partial.push(b"error /fixture/private");
        assert_eq!(
            partial
                .failure(ProbeFailureKind::TimedOut, "deadline")
                .diagnostic
                .text,
            "error <probe-input>"
        );
    }

    #[cfg(unix)]
    #[test]
    fn native_non_unicode_paths_are_scrubbed_before_lossy_decoding_and_capping() {
        use std::{ffi::OsString, os::unix::ffi::OsStringExt};
        let path = b"/fixture/private/\xffsample.crf.mkv";
        let mut tail = DiagnosticTail {
            input: OsString::from_vec(path.to_vec()).into(),
            ..DiagnosticTail::default()
        };
        for byte in path {
            tail.push(&[*byte]);
        }
        tail.push(&vec![b'x'; DIAGNOSTIC_LIMIT - path.len() / 2]);
        let failure = tail.failure(ProbeFailureKind::Rejected { code: Some(1) }, "rejected");
        assert!(!failure.diagnostic.text.contains("sample.crf.mkv"));
        assert!(!failure.diagnostic.text.contains('\u{fffd}'));
        assert!(failure.diagnostic.text.contains("<probe-input>"));
    }

    #[test]
    fn diagnostic_keeps_the_tail_across_small_and_oversized_chunks() {
        let mut tail = DiagnosticTail::default();
        tail.push(b"initial");
        tail.push(&vec![b'x'; DIAGNOSTIC_LIMIT * 2]);
        tail.push(b"last diagnostic");
        let failure = tail.failure(ProbeFailureKind::TimedOut, "deadline");
        assert_eq!(failure.diagnostic.text.len(), DIAGNOSTIC_LIMIT);
        assert!(failure.diagnostic.text.ends_with("last diagnostic"));
        assert!(failure.diagnostic.truncated);
    }

    #[test]
    fn invalid_utf8_diagnostics_remain_bounded_after_lossy_decoding() {
        let mut tail = DiagnosticTail::default();
        tail.push(&vec![0xff; DIAGNOSTIC_LIMIT]);
        let failure = tail.failure(ProbeFailureKind::Rejected { code: Some(1) }, "rejected");
        assert!(failure.diagnostic.text.len() <= DIAGNOSTIC_LIMIT);
        assert!(failure.diagnostic.truncated);
    }

    #[test]
    fn failure_display_retains_primary_diagnostics_and_cleanup_errors() {
        let mut tail = DiagnosticTail::default();
        tail.push(b"probe stderr");
        let mut failure = tail.failure(ProbeFailureKind::TimedOut, "deadline");
        failure.cleanup_failures = vec!["kill failure".into(), "wait failure".into()];
        let message = failure.to_string();
        for expected in ["deadline", "probe stderr", "kill failure", "wait failure"] {
            assert!(message.contains(expected));
        }
    }
}
