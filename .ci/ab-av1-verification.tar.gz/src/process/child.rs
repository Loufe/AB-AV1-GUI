use log::info;
use process_wrap::tokio::{ChildWrapper, CommandWrap, KillOnDrop};
use std::{
    io::{self, IsTerminal},
    mem,
    pin::Pin,
    process::{ExitStatus, Output, Stdio},
    sync::{Arc, LazyLock, Mutex},
    time::Duration,
};
use tokio::{
    io::{AsyncReadExt, BufReader},
    process::{ChildStderr, ChildStdout, Command},
    sync::Mutex as AsyncMutex,
    time::{Instant, timeout_at},
};
use tokio_stream::{Stream, StreamExt};

use super::Item;

type ChildHandle = Arc<AsyncMutex<ManagedChild>>;

pub struct ManagedChild {
    child: Box<dyn ChildWrapper>,
    settled: bool,
}

impl ManagedChild {
    async fn terminate(&mut self) -> Vec<String> {
        if self.settled {
            return Vec::new();
        }
        let mut errors = Vec::new();
        if let Err(error) = self.child.start_kill()
            && !already_empty(&error)
        {
            errors.push(format!("termination: {error}"));
        }
        if let Err(error) = self.child.wait().await {
            errors.push(format!("wait: {error}"));
        }
        self.settled = errors.is_empty();
        errors
    }
}

static RUNNING: LazyLock<Mutex<Vec<ChildHandle>>> = LazyLock::new(<_>::default);

/// Output stream for a process registered for job finalization.
pub struct ManagedChunkStream {
    stream: Pin<Box<dyn Stream<Item = Item>>>,
    child: ChildHandle,
}

impl ManagedChunkStream {
    pub fn child(&self) -> &ChildHandle {
        &self.child
    }
}

impl Stream for ManagedChunkStream {
    type Item = Item;

    fn poll_next(
        mut self: Pin<&mut Self>,
        cx: &mut std::task::Context<'_>,
    ) -> std::task::Poll<Option<Self::Item>> {
        self.stream.as_mut().poll_next(cx)
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        self.stream.size_hint()
    }
}

/// Spawn a command in an OS process group and register it immediately.
pub fn spawn(mut command: Command) -> io::Result<ManagedChunkStream> {
    command.stdout(Stdio::piped()).stderr(Stdio::piped());

    let mut command = CommandWrap::from(command);
    command.wrap(KillOnDrop);
    #[cfg(unix)]
    command.wrap(process_wrap::tokio::ProcessGroup::leader());
    #[cfg(windows)]
    command
        .wrap(process_wrap::tokio::CreationFlags(
            windows::Win32::System::Threading::CREATE_NO_WINDOW,
        ))
        .wrap(process_wrap::tokio::JobObject);
    let mut child = command.spawn()?;
    let stdout = child
        .stdout()
        .take()
        .ok_or_else(|| io::Error::other("child stdout was not piped"))?;
    let stderr = child
        .stderr()
        .take()
        .ok_or_else(|| io::Error::other("child stderr was not piped"))?;
    let child = Arc::new(AsyncMutex::new(ManagedChild {
        child,
        settled: false,
    }));
    RUNNING.lock().unwrap().push(Arc::clone(&child));

    let stream_child = Arc::clone(&child);
    let stream = Box::pin(chunk_stream(stdout, stderr, stream_child));
    Ok(ManagedChunkStream { stream, child })
}

/// Run a registered command to completion and collect its output.
pub async fn output(command: Command) -> io::Result<Output> {
    let mut stream = spawn(command)?;
    let mut stdout = Vec::new();
    let mut stderr = Vec::new();
    let status = loop {
        match stream.next().await {
            Some(Item::Stdout(chunk)) => stdout.extend(chunk),
            Some(Item::Stderr(chunk)) => stderr.extend(chunk),
            Some(Item::Done(status)) => break status?,
            None => return Err(io::Error::other("child ended without an exit status")),
        }
    };
    Ok(Output {
        status,
        stdout,
        stderr,
    })
}

fn chunk_stream(
    stdout: ChildStdout,
    stderr: ChildStderr,
    child: ChildHandle,
) -> impl Stream<Item = Item> {
    async_stream::stream! {
        let mut stdout = BufReader::new(stdout);
        let mut stderr = BufReader::new(stderr);
        let mut stdout_open = true;
        let mut stderr_open = true;
        let mut stdout_buf = vec![0; 4096];
        let mut stderr_buf = vec![0; 4096];
        // Descendants can retain inherited pipe handles even when their selected
        // standard streams are null. Leader exit must trigger tree settlement.
        let completion = wait_one(&child);
        tokio::pin!(completion);
        let mut status = None;

        while stdout_open || stderr_open {
            tokio::select! {
                result = &mut completion, if status.is_none() => status = Some(result),
                read = stdout.read(&mut stdout_buf), if stdout_open => match read {
                    Ok(0) => stdout_open = false,
                    Ok(len) => yield Item::Stdout(stdout_buf[..len].to_vec()),
                    Err(error) => {
                        yield Item::Done(Err(error));
                        return;
                    }
                },
                read = stderr.read(&mut stderr_buf), if stderr_open => match read {
                    Ok(0) => stderr_open = false,
                    Ok(len) => yield Item::Stderr(stderr_buf[..len].to_vec()),
                    Err(error) => {
                        yield Item::Done(Err(error));
                        return;
                    }
                },
            }
        }

        yield Item::Done(match status {
            Some(status) => status,
            None => completion.await,
        });
    }
}

/// Wait for all registered process groups to exit.
pub async fn wait() -> anyhow::Result<()> {
    let mut log_deadline = Some(Instant::now() + Duration::from_millis(500));
    let processes = mem::take(&mut *RUNNING.lock().unwrap());
    let mut errors = Vec::new();

    for (index, process) in processes.into_iter().enumerate() {
        let waited = match log_deadline {
            Some(deadline) => match timeout_at(deadline, wait_one(&process)).await {
                Ok(waited) => waited,
                Err(_) => {
                    log_waiting();
                    log_deadline = None;
                    wait_one(&process).await
                }
            },
            None => wait_one(&process).await,
        };
        if let Err(error) = waited {
            errors.push(format!("child {index}: {error}"));
        }
    }

    collected_errors("failed to wait for child processes", errors)
}

/// Terminate every registered process group and wait for it to exit.
pub async fn kill_all() -> anyhow::Result<()> {
    let processes = mem::take(&mut *RUNNING.lock().unwrap());
    let mut errors = Vec::new();

    for (index, process) in processes.into_iter().enumerate() {
        for error in terminate(&process).await {
            errors.push(format!("child {index} {error}"));
        }
    }

    collected_errors("failed to terminate child processes", errors)
}

/// Leader exit does not establish that its process group or Job is empty.
pub(crate) async fn terminate(process: &ChildHandle) -> Vec<String> {
    let mut child = process.lock().await;
    let errors = child.terminate().await;
    if child.settled {
        retire(process);
    }
    errors
}

pub(super) async fn wait_one(process: &ChildHandle) -> io::Result<ExitStatus> {
    loop {
        {
            // A detached sample producer can still own its stream during cancellation.
            // Never hold this mutex across an unfinished leader wait: the finalizer
            // must be able to acquire it and send the process-tree kill.
            let mut child = process.lock().await;
            if let Some(status) = child.child.inner_mut().try_wait()? {
                let errors = child.terminate().await;
                if child.settled {
                    retire(process);
                }
                return if errors.is_empty() {
                    Ok(status)
                } else {
                    Err(io::Error::other(errors.join("; ")))
                };
            }
        }
        tokio::time::sleep(Duration::from_millis(10)).await;
    }
}

fn retire(process: &ChildHandle) {
    RUNNING
        .lock()
        .unwrap()
        .retain(|registered| !Arc::ptr_eq(registered, process));
}

fn already_empty(error: &io::Error) -> bool {
    if matches!(
        error.kind(),
        io::ErrorKind::InvalidInput | io::ErrorKind::NotFound
    ) {
        return true;
    }
    #[cfg(unix)]
    {
        // killpg(2) reports ESRCH when the complete group already exited.
        error.raw_os_error() == Some(3)
    }
    #[cfg(not(unix))]
    {
        false
    }
}

fn log_waiting() {
    match std::io::stderr().is_terminal() {
        true => eprintln!("Waiting for child processes to exit..."),
        _ => info!("Waiting for child processes to exit"),
    }
}

fn collected_errors(context: &str, errors: Vec<String>) -> anyhow::Result<()> {
    if errors.is_empty() {
        Ok(())
    } else {
        anyhow::bail!("{context}:\n{}", errors.join("\n"))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::Path;

    #[tokio::test]
    async fn leader_exit_settles_descendants_before_pipe_eof() -> anyhow::Result<()> {
        let marker =
            std::env::temp_dir().join(format!("ab-av1-child-heartbeat-{}", std::process::id()));
        let mut command = Command::new(std::env::current_exe()?);
        command.args([
            "--exact",
            "process::child::tests::orphan_fixture",
            "--nocapture",
        ]);
        command.env("AB_AV1_ORPHAN_MARKER", &marker);
        let mut stream = spawn(command)?;
        let handle = Arc::clone(stream.child());
        tokio::time::timeout(Duration::from_secs(5), async {
            loop {
                match stream.next().await {
                    Some(Item::Done(status)) => {
                        assert!(status?.success());
                        break;
                    }
                    Some(_) => {}
                    None => return Err(io::Error::other("child ended without status")),
                }
            }
            Ok(())
        })
        .await??;
        assert!(handle.lock().await.settled);
        let heartbeat = std::fs::read(&marker)?;
        tokio::time::sleep(Duration::from_millis(50)).await;
        assert_eq!(std::fs::read(&marker)?, heartbeat);
        std::fs::remove_file(marker)?;
        Ok(())
    }

    #[tokio::test(flavor = "current_thread")]
    async fn finalizer_can_terminate_a_stream_still_owned_by_a_producer() -> anyhow::Result<()> {
        let local = tokio::task::LocalSet::new();
        local
            .run_until(async {
                let marker = std::env::temp_dir()
                    .join(format!("ab-av1-copy-heartbeat-{}", std::process::id()));
                let mut command = Command::new(std::env::current_exe()?);
                command.args([
                    "--exact",
                    "process::child::tests::heartbeat_fixture",
                    "--nocapture",
                ]);
                command.env("AB_AV1_HEARTBEAT_MARKER", &marker);
                let mut stream = spawn(command)?;
                let handle = Arc::clone(stream.child());
                let (ready_tx, ready_rx) = tokio::sync::oneshot::channel();
                let producer = tokio::task::spawn_local(async move {
                    use std::future::{Future, poll_fn};
                    let mut ready = Some(ready_tx);
                    loop {
                        let next = stream.next();
                        tokio::pin!(next);
                        let item = poll_fn(|cx| {
                            let result = next.as_mut().poll(cx);
                            if result.is_pending()
                                && let Some(ready) = ready.take()
                            {
                                let _ = ready.send(());
                            }
                            result
                        })
                        .await;
                        match item {
                            Some(Item::Done(status)) => return status,
                            Some(_) => {}
                            None => return Err(io::Error::other("producer ended without status")),
                        }
                    }
                });
                tokio::time::timeout(Duration::from_secs(5), ready_rx).await??;
                let deadline = Instant::now() + Duration::from_secs(5);
                while !marker.exists() {
                    anyhow::ensure!(
                        Instant::now() < deadline,
                        "sample-copy fixture did not become ready"
                    );
                    tokio::time::sleep(Duration::from_millis(5)).await;
                }
                tokio::time::timeout(Duration::from_secs(5), async {
                    assert!(terminate(&handle).await.is_empty());
                    producer.await??;
                    Ok::<_, anyhow::Error>(())
                })
                .await??;
                let heartbeat = std::fs::read(&marker)?;
                tokio::time::sleep(Duration::from_millis(50)).await;
                assert_eq!(std::fs::read(&marker)?, heartbeat);
                std::fs::remove_file(marker)?;
                Ok::<_, anyhow::Error>(())
            })
            .await
    }

    #[test]
    fn orphan_fixture() -> anyhow::Result<()> {
        let Some(marker) = std::env::var_os("AB_AV1_ORPHAN_MARKER") else {
            return Ok(());
        };
        let _child = std::process::Command::new(std::env::current_exe()?)
            .args(["--exact", "process::child::tests::heartbeat_fixture"])
            .env("AB_AV1_HEARTBEAT_MARKER", &marker)
            .stdout(Stdio::null())
            .stderr(Stdio::null())
            .spawn()?;
        let deadline = std::time::Instant::now() + Duration::from_secs(5);
        while !Path::new(&marker).exists() {
            anyhow::ensure!(
                std::time::Instant::now() < deadline,
                "descendant did not become ready"
            );
            std::thread::sleep(Duration::from_millis(5));
        }
        Ok(())
    }

    #[test]
    fn heartbeat_fixture() -> anyhow::Result<()> {
        let Some(marker) = std::env::var_os("AB_AV1_HEARTBEAT_MARKER") else {
            return Ok(());
        };
        let mut counter = 0_u64;
        loop {
            std::fs::write(&marker, counter.to_string())?;
            counter = counter.wrapping_add(1);
            std::thread::sleep(Duration::from_millis(5));
        }
    }

    #[tokio::test]
    async fn completed_child_is_retired_and_settlement_is_idempotent() -> anyhow::Result<()> {
        let mut command = Command::new(std::env::current_exe()?);
        command.arg("--list");
        let mut stream = spawn(command)?;
        let handle = Arc::clone(stream.child());
        while let Some(item) = stream.next().await {
            if let Item::Done(status) = item {
                assert!(status?.success());
            }
        }
        assert!(handle.lock().await.settled);
        assert!(
            !RUNNING
                .lock()
                .unwrap()
                .iter()
                .any(|child| Arc::ptr_eq(child, &handle))
        );
        assert!(terminate(&handle).await.is_empty());
        Ok(())
    }
}
